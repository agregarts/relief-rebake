# SPDX-FileCopyrightText: 2026 Agregart
#
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Relief Rebake - rebuild messy relief meshes as clean quad height fields.
# Developed with AI assistance.

"""
Relief Rebake
=============

Takes a messy relief mesh - AI-generated, photogrammetry, remeshed, or just
badly distorted - and rebuilds it as a clean quad height field.

It ray-casts the object from above onto a regular grid, cleans up the
resulting height map, then builds a fresh watertight mesh with even quad
topology, straight side walls and a flat base. Every height value is kept;
only the grid underneath is replaced.

Image-to-3D tools produce relief panels with unusable topology: uneven
triangle density, stretched faces, geometry wasted on a back plate.
Retopology tools smooth them out and lose the detail. This keeps the detail
and replaces the grid.

The relief must face +Z. If it does not, rotate it and apply the rotation
with Ctrl+A > Rotation before running.

Resolution cost is quadratic. Start at 1575 and raise it once you like the
result:

    RES    grid           quads     time       RAM
    1000   1000 x  667     0.7M     ~3 min     ~0.5 GB
    1575   1575 x 1050     1.7M     ~7 min     ~1 GB
    3150   3150 x 2100     6.6M     ~30 min    ~4 GB
    4725   4725 x 3150    14.9M     ~60 min    ~8-12 GB

Overhangs are lost by design: a height field stores one Z per XY position.
For relief panels this is not a limitation; for undercut sculpture it is.
"""

import math
import time

import bpy
import bmesh
import numpy as np
from bpy.props import BoolProperty, FloatProperty, IntProperty, StringProperty
from mathutils import Vector
from mathutils.bvhtree import BVHTree


# ---------------------------------------------------------------- image tools

def gaussian_blur(a, sigma):
    if sigma <= 0:
        return a
    r = max(1, int(math.ceil(sigma * 3)))
    x = np.arange(-r, r + 1, dtype=np.float32)
    k = np.exp(-(x * x) / (2 * sigma * sigma))
    k /= k.sum()
    p = np.pad(a, ((r, r), (0, 0)), mode='edge')
    o = np.zeros_like(a)
    for i in range(k.size):
        o += k[i] * p[i:i + a.shape[0], :]
    p = np.pad(o, ((0, 0), (r, r)), mode='edge')
    o2 = np.zeros_like(o)
    for i in range(k.size):
        o2 += k[i] * p[:, i:i + o.shape[1]]
    return o2


def median3(a, band=512):
    """3x3 median, processed in horizontal bands to keep memory low."""
    H, W = a.shape
    out = np.empty_like(a)
    p = np.pad(a, 1, mode='edge')
    for y0 in range(0, H, band):
        y1 = min(y0 + band, H)
        h = y1 - y0
        st = np.empty((9, h, W), dtype=np.float32)
        n = 0
        for i in range(3):
            for j in range(3):
                st[n] = p[y0 + i:y0 + i + h, j:j + W]
                n += 1
        out[y0:y1] = np.median(st, axis=0)
        del st
    return out


# ------------------------------------------------------------------- sampling

def sample_heightfield(obj, res, report):
    dg = bpy.context.evaluated_depsgraph_get()
    ev = obj.evaluated_get(dg)
    me = ev.to_mesh()
    mw = obj.matrix_world
    verts = [mw @ v.co for v in me.vertices]
    polys = [tuple(p.vertices) for p in me.polygons]
    tree = BVHTree.FromPolygons(verts, polys, all_triangles=False, epsilon=0.0)
    vs = np.array([[v.x, v.y, v.z] for v in verts], dtype=np.float64)
    ev.to_mesh_clear()
    del verts, polys

    xmin, ymin, zmin = vs.min(0)
    xmax, ymax, zmax = vs.max(0)
    del vs
    sx, sy = xmax - xmin, ymax - ymin
    if sx <= 0 or sy <= 0:
        raise ValueError("Object has no XY extent. The relief must face +Z.")

    if sx >= sy:
        W = int(res)
        H = max(2, int(round(res * sy / sx)))
    else:
        H = int(res)
        W = max(2, int(round(res * sx / sy)))

    report("grid: %d x %d = %.2fM rays" % (W, H, W * H / 1e6))

    xs = np.linspace(xmin, xmax, W)
    ys = np.linspace(ymin, ymax, H)
    top = zmax + max(sx, sy) * 0.1
    down = Vector((0.0, 0.0, -1.0))

    hf = np.full((H, W), np.nan, dtype=np.float32)
    hit = 0
    t0 = time.time()
    step = max(1, H // 50)
    origin = Vector((0.0, 0.0, top))
    cast = tree.ray_cast

    for j in range(H):
        origin.y = float(ys[j])
        row = hf[j]
        for i in range(W):
            origin.x = float(xs[i])
            loc = cast(origin, down)[0]
            if loc is not None:
                row[i] = loc.z
                hit += 1
        if j % step == 0 and j:
            el = time.time() - t0
            report("%d%%  elapsed %.1f min  remaining ~%.1f min"
                   % (int(100 * j / H), el / 60.0, el * (H - j) / j / 60.0))

    report("ray casting done in %.1f min, hit rate %.1f%%"
           % ((time.time() - t0) / 60.0, 100.0 * hit / (W * H)))
    if hit == 0:
        raise ValueError("No rays hit the object. Check the facing direction.")

    miss = np.isnan(hf)
    if miss.any():
        report("filling gaps: %d cells" % int(miss.sum()))
        hf[miss] = zmin
        for _ in range(3):
            f = median3(hf)
            hf[miss] = f[miss]
    return hf, (float(zmin), float(zmax))


def process(hf, zr, op, report):
    zmin, zmax = zr
    rng = zmax - zmin
    if rng <= 0:
        raise ValueError("Height range is zero.")
    h = (hf - zmin) / rng

    if op.despeckle:
        m = median3(h)
        spike = np.abs(h - m) > 0.06
        h = np.where(spike, m, h)
        report("spikes removed: %d px" % int(spike.sum()))
        del m, spike

    if op.smooth > 0:
        bl = gaussian_blur(h, op.smooth)
        if op.detail_boost > 0:
            fine = gaussian_blur(h, op.smooth * 0.4)
            h = bl + (fine - bl) * op.detail_boost
        else:
            h = bl

    if op.flatten_floor > 0:
        h = np.clip((h - op.flatten_floor) / (1.0 - op.flatten_floor), 0.0, 1.0)
    return np.clip(h, 0.0, 1.0).astype(np.float32), rng


# ------------------------------------------------------------- mesh building

def _geometry_arrays(hm, size_x, size_y, depth, base):
    H, W = hm.shape
    xs = np.linspace(-size_x * .5, size_x * .5, W, dtype=np.float32)
    ys = np.linspace(-size_y * .5, size_y * .5, H, dtype=np.float32)
    X, Y = np.meshgrid(xs, ys)
    Z = base + hm * depth

    top_co = np.stack([X, Y, Z], -1).reshape(-1, 3)
    del X, Y, Z

    idx = np.arange(W * H, dtype=np.int32).reshape(H, W)
    top_f = np.stack([idx[:-1, :-1], idx[:-1, 1:],
                      idx[1:, 1:], idx[1:, :-1]], -1).reshape(-1, 4)
    n_top = top_f.shape[0]

    per = np.concatenate([
        idx[0, :],
        idx[1:, W - 1],
        idx[H - 1, W - 2::-1],
        idx[H - 2:0:-1, 0],
    ]).astype(np.int32)
    P = per.size
    bs = W * H

    skirt_co = top_co[per].copy()
    skirt_co[:, 2] = 0.0

    nxt = np.roll(np.arange(P, dtype=np.int32), -1)
    side_f = np.stack([per, bs + np.arange(P, dtype=np.int32),
                       bs + nxt, per[nxt]], -1)

    cen = bs + P
    cen_co = np.zeros((1, 3), dtype=np.float32)
    bot_f = np.stack([np.full(P, cen, dtype=np.int32),
                      bs + nxt,
                      bs + np.arange(P, dtype=np.int32)], -1)

    co = np.concatenate([top_co, skirt_co, cen_co], 0).astype(np.float32)
    return co, top_f, side_f, bot_f, n_top


def _add_uv(mesh, W, H):
    uvl = mesh.uv_layers.new(name="UVMap")
    nl = len(mesh.loops)
    lv = np.empty(nl, dtype=np.int32)
    mesh.loops.foreach_get("vertex_index", lv)
    uv = np.zeros((nl, 2), dtype=np.float32)
    m = lv < (W * H)
    tv = lv[m]
    uv[m, 0] = (tv % W) / float(W - 1)
    uv[m, 1] = (tv // W) / float(H - 1)
    uvl.data.foreach_set("uv", uv.ravel())


def build_mesh_fast(hm, size_x, size_y, depth, op, report):
    co, top_f, side_f, bot_f, n_top = _geometry_arrays(
        hm, size_x, size_y, depth, float(op.base))

    nv = co.shape[0]
    n_quad = top_f.shape[0] + side_f.shape[0]
    n_tri = bot_f.shape[0]
    n_poly = n_quad + n_tri
    n_loop = n_quad * 4 + n_tri * 3
    report("%d verts, %d polys, %d loops" % (nv, n_poly, n_loop))

    mesh = bpy.data.meshes.new(op.object_name)
    mesh.vertices.add(nv)
    mesh.loops.add(n_loop)
    mesh.polygons.add(n_poly)

    mesh.vertices.foreach_set("co", co.ravel())
    del co

    loop_verts = np.concatenate([top_f.ravel(), side_f.ravel(), bot_f.ravel()])
    mesh.loops.foreach_set("vertex_index", loop_verts)
    del loop_verts

    totals = np.empty(n_poly, dtype=np.int32)
    totals[:n_quad] = 4
    totals[n_quad:] = 3
    starts = np.zeros(n_poly, dtype=np.int32)
    np.cumsum(totals[:-1], out=starts[1:])

    mesh.polygons.foreach_set("loop_start", starts)
    try:
        mesh.polygons.foreach_set("loop_total", totals)
    except Exception:
        pass          # Blender 4.1+ derives loop_total from offsets

    if op.shade_smooth:
        sm = np.zeros(n_poly, dtype=bool)
        sm[:n_top] = True
        mesh.polygons.foreach_set("use_smooth", sm)

    mesh.update(calc_edges=True)
    corrected = mesh.validate(verbose=False)
    if len(mesh.polygons) < n_poly * 0.99:
        raise RuntimeError("fast path failed validation (%d/%d polys)"
                           % (len(mesh.polygons), n_poly))
    if corrected:
        report("note: validate corrected some geometry")

    if op.make_uv:
        _add_uv(mesh, hm.shape[1], hm.shape[0])
    return mesh


def build_mesh_slow(hm, size_x, size_y, depth, op, report):
    report("falling back to from_pydata - this will be slow")
    co, top_f, side_f, bot_f, n_top = _geometry_arrays(
        hm, size_x, size_y, depth, float(op.base))
    faces = top_f.tolist() + side_f.tolist() + bot_f.tolist()
    mesh = bpy.data.meshes.new(op.object_name)
    mesh.from_pydata(co.astype(np.float64).tolist(), [], faces)
    mesh.validate(verbose=False)
    mesh.update()
    if op.shade_smooth:
        sm = np.zeros(len(mesh.polygons), dtype=bool)
        sm[:n_top] = True
        mesh.polygons.foreach_set("use_smooth", sm)
        mesh.update()
    if op.make_uv:
        _add_uv(mesh, hm.shape[1], hm.shape[0])
    return mesh


# ------------------------------------------------------------------- operator

class MESH_OT_relief_rebake(bpy.types.Operator):
    """Rebuild the selected relief mesh as a clean quad height field"""
    bl_idname = "mesh.relief_rebake"
    bl_label = "Relief Rebake"
    bl_options = {'REGISTER', 'UNDO'}

    resolution: IntProperty(
        name="Resolution",
        description="Output grid width. Cost is quadratic: doubling this "
                    "quadruples time and memory. Start at 1575",
        default=1575, min=64, max=12000)

    despeckle: BoolProperty(
        name="Despeckle",
        description="Remove single-pixel spikes left by the ray cast",
        default=True)

    smooth: FloatProperty(
        name="Smooth",
        description="Gaussian blur on the height field. Any value above 0 "
                    "softens detail",
        default=0.0, min=0.0, max=20.0)

    detail_boost: FloatProperty(
        name="Detail Boost",
        description="Only used when Smooth is above 0. Re-adds fine detail",
        default=0.0, min=0.0, max=4.0)

    flatten_floor: FloatProperty(
        name="Flatten Floor",
        description="Heights below this fraction snap to the base plane. "
                    "Clears ray-cast noise in the background",
        default=0.015, min=0.0, max=0.5, subtype='FACTOR')

    relief_depth: FloatProperty(
        name="Relief Depth",
        description="0 keeps the original depth. Set a value to rescale it",
        default=0.0, min=0.0, unit='LENGTH')

    base: FloatProperty(
        name="Base Thickness",
        description="Solid base under the relief",
        default=3.0, min=0.0, unit='LENGTH')

    object_name: StringProperty(
        name="Object Name", default="Relief_Clean")

    shade_smooth: BoolProperty(name="Shade Smooth", default=True)
    triangulate: BoolProperty(name="Triangulate", default=False)

    make_uv: BoolProperty(
        name="Create UVs",
        description="Off by default. At high resolution the UV layer alone "
                    "can cost hundreds of megabytes",
        default=False)

    fast_build: BoolProperty(
        name="Fast Build",
        description="Write geometry straight from numpy arrays. Falls back "
                    "to from_pydata automatically if it fails",
        default=True)

    hide_source: BoolProperty(name="Hide Source Object", default=True)

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and ob.mode == 'OBJECT'

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.prop(self, "resolution")
        quads = self.resolution * self.resolution * 0.667 / 1e6
        col.label(text="roughly %.1fM quads" % quads,
                  icon='ERROR' if quads > 8 else 'INFO')

        layout.separator()
        col = layout.column(align=True)
        col.prop(self, "despeckle")
        col.prop(self, "flatten_floor")
        col.prop(self, "smooth")
        if self.smooth > 0:
            col.prop(self, "detail_boost")

        layout.separator()
        col = layout.column(align=True)
        col.prop(self, "relief_depth")
        col.prop(self, "base")
        col.prop(self, "object_name")

        layout.separator()
        col = layout.column(align=True)
        col.prop(self, "shade_smooth")
        col.prop(self, "triangulate")
        col.prop(self, "make_uv")
        col.prop(self, "fast_build")
        col.prop(self, "hide_source")

    def execute(self, context):
        def report(msg):
            print("[Relief Rebake] " + msg)

        src = context.active_object
        t_all = time.time()
        report("source: %s | resolution %d" % (src.name, self.resolution))

        try:
            hf, zr = sample_heightfield(src, int(self.resolution), report)
            hm, rng = process(hf, zr, self, report)
            del hf
        except Exception as ex:
            self.report({'ERROR'}, str(ex))
            return {'CANCELLED'}

        bb = [src.matrix_world @ Vector(v) for v in src.bound_box]
        size_x = max(v.x for v in bb) - min(v.x for v in bb)
        size_y = max(v.y for v in bb) - min(v.y for v in bb)
        depth = float(self.relief_depth) if self.relief_depth > 0 else rng

        mesh = None
        if self.fast_build:
            try:
                mesh = build_mesh_fast(hm, size_x, size_y, depth, self, report)
            except Exception as ex:
                report("fast path failed: %s" % ex)
                mesh = None
        if mesh is None:
            mesh = build_mesh_slow(hm, size_x, size_y, depth, self, report)

        if self.triangulate:
            bm = bmesh.new()
            bm.from_mesh(mesh)
            bmesh.ops.triangulate(bm, faces=bm.faces[:])
            bm.to_mesh(mesh)
            bm.free()
            mesh.update()

        old = bpy.data.objects.get(self.object_name)
        if old is not None and old.type == 'MESH':
            od = old.data
            old.data = mesh
            if od.users == 0:
                bpy.data.meshes.remove(od)
            obj = old
        else:
            obj = bpy.data.objects.new(self.object_name, mesh)
            context.collection.objects.link(obj)

        if self.hide_source:
            src.hide_set(True)
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        msg = ("%s: %d verts in %.1f min"
               % (obj.name, len(mesh.vertices), (time.time() - t_all) / 60.0))
        report(msg)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class VIEW3D_PT_relief_rebake(bpy.types.Panel):
    bl_label = "Relief Rebake"
    bl_idname = "VIEW3D_PT_relief_rebake"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        ob = context.active_object

        box = layout.box()
        box.label(text="The relief must face +Z", icon='INFO')
        box.label(text="Adjust settings after running (F9)")

        col = layout.column()
        col.scale_y = 1.4
        col.operator("mesh.relief_rebake", icon='MOD_REMESH')

        if ob is not None and ob.type == 'MESH':
            layout.label(text="Source: %s (%d verts)"
                              % (ob.name, len(ob.data.vertices)))


def menu_func(self, context):
    self.layout.operator("mesh.relief_rebake", icon='MOD_REMESH')


classes = (MESH_OT_relief_rebake, VIEW3D_PT_relief_rebake)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.VIEW3D_MT_object.append(menu_func)


def unregister():
    bpy.types.VIEW3D_MT_object.remove(menu_func)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
